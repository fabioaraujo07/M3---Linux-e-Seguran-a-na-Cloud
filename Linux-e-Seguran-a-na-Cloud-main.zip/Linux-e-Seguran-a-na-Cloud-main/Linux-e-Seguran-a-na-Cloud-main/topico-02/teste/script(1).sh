#!/bin/bash

echo "SkodjiDigital"
