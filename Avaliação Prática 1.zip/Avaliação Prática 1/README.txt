# Tópico 1 - Preparação do ambiente Linux

## Ambiente utilizado
VM local correndo Ubuntu Server LTS 26.04

## Objetivo desta atividade
Preparar o ambiente Linux e organizar a primeira evidência técnica.

## Estrutura criada
linux-seguranca-cloud/
└── modulo-final/
    └── topico-01/
        └── evidencias/
            ├── comandos-topico-01.txt
            └── README.md

## Comandos executados

apt-get - Fazer update e instalar dependências no Ubuntu

mkdir - Criar um diretório/pasta

touch - Criar ficheiros

ls - Listar elementos do diretório

nano - Editor de texto no terminal

clear - Limpar o terminal

tree - Mostrar toda a estrutura de diretórios e ficheiros

## Diferença entre VM, VPS e infraestrutura em nuvem
VM → Máquina virtual com Linux isolado dentro de um servidor físico.
VPS → Tipo de VM usada como servidor privado com acesso root.
Cloud → Infraestrutura online com vários servidores, mais escalável e segura.

## Dificuldades encontradas
Nenhuma

